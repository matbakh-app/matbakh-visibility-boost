// Lambda function to setup auth database tables
const { getPgClient, executeQuery } = require('/opt/nodejs/pgClient');

exports.handler = async (event) => {
  try {
    console.log('Setting up auth database tables...');
    
    await getPgClient(); // ensure pool
    
    // Create app_users table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS app_users (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        email text UNIQUE NOT NULL,
        name text,
        verified_at timestamptz,
        created_at timestamptz NOT NULL DEFAULT now()
      )
    `);
    console.log('✅ app_users table created');
    
    // Create auth_magic_tokens table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS auth_magic_tokens (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        email text NOT NULL,
        token_hash text NOT NULL UNIQUE,
        expires_at timestamptz NOT NULL,
        consumed_at timestamptz,
        user_agent text,
        ip text,
        created_at timestamptz NOT NULL DEFAULT now()
      )
    `);
    console.log('✅ auth_magic_tokens table created');
    
    // Create indexes
    await executeQuery(`CREATE INDEX IF NOT EXISTS idx_auth_magic_tokens_email ON auth_magic_tokens(email)`);
    await executeQuery(`CREATE INDEX IF NOT EXISTS idx_auth_magic_tokens_expires ON auth_magic_tokens(expires_at)`);
    console.log('✅ Indexes created');
    
    // Verify tables
    const appUsersCount = await executeQuery('SELECT count(*) FROM app_users');
    const tokensCount = await executeQuery('SELECT count(*) FROM auth_magic_tokens');
    
    console.log(`📊 app_users: ${appUsersCount.rows[0].count} rows`);
    console.log(`📊 auth_magic_tokens: ${tokensCount.rows[0].count} rows`);
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: 'Auth database tables created successfully',
        tables: {
          app_users: appUsersCount.rows[0].count,
          auth_magic_tokens: tokensCount.rows[0].count
        }
      })
    };
  } catch (error) {
    console.error('Database setup error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};